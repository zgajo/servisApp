 <div class="box box-info" style="border-top: none">

                    <div class="box-body">
                        <h4>Prikaz primki sa serijskim: <?php echo $_GET['pregled_serijski'] ?></h4>
                        <table id="serijski_primke" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Primka</th>
                                    <th>Datum zaprimanja</th>
                                    <th>Uređaj</th>
                                    <th>Stranka</th>
                                    <th>Status primke</th>
                                    
                                </tr>
                            </thead>
                        </table>
                    </div><!-- /.box-body -->

                    <div style="clear: both">

                    </div><!-- /.box-footer -->
                </div><!-- /.box -->