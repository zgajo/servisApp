
 <!-- TABLE: Svi otvoreni radni nalozi -->
                        
                        <!-- TABLE: Sve otvorene primke -->
                        <div class="box box-info"  style="border-top: none">
                            <div class="box-body">
                                    <table  id="sviRMA" class="table table-bordered table-striped"  >
                                        <thead>
                                            <tr>
                                                <th>Primka</th>
                                                <th>Stranka</th>
                                                <th>Uređaj</th>
                                                <th>Serijski</th>
                                                <th>RMA nalog</th>
                                                <th>Radni nalog OS-a</th>
                                                <th>Naziv OS-a</th>
                                                <th>Poslano u OS</th>
                                                <th>Status</th>
                                                <th>Napomena</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                            </div><!-- /.box-body -->
                            <div  class="box-footer clearfix">
                                
                            </div><!-- /.box-footer -->
                        </div><!-- /.box -->
                        