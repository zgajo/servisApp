
 <!-- TABLE: Svi otvoreni radni nalozi -->
                        
                        <!-- TABLE: Sve otvorene primke -->
                        <div class="box box-info"  style="border-top: none">
                            <div class="box-body">
                                    <table  id="sviRN"  class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Primka</th>
                                                <th>RN</th>
                                                <th>Uređaj</th>
                                                <th>Serijski</th>
                                                <th>Stranka</th>
                                                <th>Status radnog naloga</th>
                                                <th>Napomena</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                            </div><!-- /.box-body -->
                            <div  class="box-footer clearfix">
                                
                            </div><!-- /.box-footer -->
                        </div><!-- /.box -->
                        